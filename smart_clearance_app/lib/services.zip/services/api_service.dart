import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  // For web + PC testing (localhost)
  static const String baseUrl = "http://localhost:5000";

      // Login API
      static Future<Map<String, dynamic>> login(String email, String password, String role) async {
        final url = Uri.parse("$baseUrl/api/auth/login");

        final resp = await http.post(
          url,
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({
            "email": email,
            "password": password,
            "role": role,
          }),
        );

        if (resp.statusCode == 200) {
          return {
            "success": true,
            "data": jsonDecode(resp.body),
          };
        } else {
          return {
            "success": false,
            "status": resp.statusCode,
            "message": resp.body,
          };
        }
      }

  // ==========================================================
  // GET -- Clearance Requests (from clearance_request collection)
  // /api/clearance/request/:facultyId
  // ==========================================================
  static Future<Map<String, dynamic>> getClearanceRequests(String facultyId) async {
    final url = Uri.parse("$baseUrl/api/clearance/request/$facultyId");

    final resp = await http.get(url);

    if (resp.statusCode == 200) {
      return {
        "success": true,
        "data": jsonDecode(resp.body),
      };
    } else {
      return {
        "success": false,
        "status": resp.statusCode,
        "message": resp.body,
      };
    }
  }

  // ==========================================================
  // FACULTY:
  // /api/reports/:facultyId  → returns ONE report (Map)
  // ==========================================================
  static Future<Map<String, dynamic>> getClearanceReport(String facultyId) async {
    final url = Uri.parse("$baseUrl/api/reports/$facultyId");

    final resp = await http.get(url);

    if (resp.statusCode == 200) {
      return {
        "success": true,
        "data": jsonDecode(resp.body),
      };
    } else {
      return {
        "success": false,
        "status": resp.statusCode,
        "message": resp.body,
      };
    }
  }

  //==========================================================
  // FACULTY:
  // /api/reports/:facultyId  → returns LIST of departments
  // ==========================================================
  static Future<List<dynamic>> getClearanceReports(String facultyId) async {
    final url = Uri.parse("$baseUrl/api/reports/$facultyId");

    final resp = await http.get(url);

    if (resp.statusCode == 200) {
      return jsonDecode(resp.body); // return List<dynamic>
    } else {
      throw Exception(
          "Failed to fetch clearance reports: ${resp.statusCode}");
    }
  }

  
    static Future<Map<String, dynamic>> resubmitClearanceRequest(String id) async {
      final url = Uri.parse("$baseUrl/api/clearance/request/resubmit/$id");

      final res = await http.patch(url);
      return jsonDecode(res.body);
    }


static Future<Map<String, dynamic>> createClearanceRequest({
  required String facultyId,
  required String year,
  required String semester,
  required String department,      // NEW
}) async {
  final url = Uri.parse("$baseUrl/api/clearance/request");

  final resp = await http.post(
    url,
    headers: {"Content-Type": "application/json"},
    body: jsonEncode({
      "faculty_id": facultyId,
      "academic_year": year,
      "semester": semester,
      "department": department,    // NEW
    }),
  );

  if (resp.statusCode == 201) {
    return {"success": true, "data": jsonDecode(resp.body)};
  } else {
    return {"success": false, "message": resp.body};
  }
}







// ==========================================================
// ADMIN: Get ALL clearance requests
// /api/clearance/requests?year=2025–2026&semester=First%20Semester
static Future<Map<String, dynamic>> getAllClearanceRequests({
  String? year,
  String? semester,
}) async {
  final uri = Uri.parse("$baseUrl/api/clearance/requests")
      .replace(queryParameters: {
    if (year != null) "year": year,
    if (semester != null) "semester": semester,
  });

  try {
    final resp = await http.get(uri);

    if (resp.statusCode == 200) {
      final data = jsonDecode(resp.body);
      
      // If no data is returned, we consider it a "no results" condition
      if (data.isEmpty) {
        return {
          "success": false,
          "message": "No requests found",
          "data": [],
        };
      }

      return {
        "success": true,
        "data": data,
      };
    } else {
      return {
        "success": false,
        "status": resp.statusCode,
        "message": resp.body,
      };
    }
  } catch (e) {
    // Handle any exceptions that occur during the API call
    return {
      "success": false,
      "message": "Failed to load data: $e",
    };
  }
}


// ==========================================================
// ADMIN: Update request status (Approve / Reject)
// /api/clearance/request/:id
// ==========================================================
static Future<Map<String, dynamic>> updateClearanceStatus(
    String id, String status) async {
  final url = Uri.parse("$baseUrl/api/clearance/request/$id");

  final resp = await http.patch(
    url,
    headers: {"Content-Type": "application/json"},
    body: jsonEncode({"status": status}),
  );

  if (resp.statusCode == 200) {
    return {
      "success": true,
      "data": jsonDecode(resp.body),
    };
  } else {
    return {
      "success": false,
      "status": resp.statusCode,
      "message": resp.body,
    };
  }
}

static Future<Map<String, dynamic>> sendDepartmentRequest({
  required String facultyId,
  required String department,
  required String year,
  required String semester,
}) async {
  final url = Uri.parse("$baseUrl/api/clearance/request/send");

  final response = await http.post(
    url,
    headers: {"Content-Type": "application/json"},
    body: jsonEncode({
      "faculty_id": facultyId,
      "department": department,
      "academic_year": year,
      "semester": semester,
    }),
  );

  return jsonDecode(response.body);
}

static Future<Map<String, dynamic>> getRequestsByDepartment(String dept) async {
  final url = Uri.parse("$baseUrl/api/request/department/$dept");
  final res = await http.get(url);
  return jsonDecode(res.body);
}

// ==========================================================
// ADMIN (PER DEPARTMENT): Get requests for one department
// GET /api/clearance/requests/department/:dept
// ==========================================================
static Future<Map<String, dynamic>> getDepartmentRequests(
    String department) async {
  final url =
      Uri.parse("$baseUrl/api/clearance/requests/department/$department");

  try {
    final resp = await http.get(url);

    if (resp.statusCode == 200) {
      // Backend already returns: { success: true, data: [...] }
      return jsonDecode(resp.body) as Map<String, dynamic>;
    } else {
      return {
        "success": false,
        "status": resp.statusCode,
        "message": resp.body,
        "data": [],
      };
    }
  } catch (e) {
    return {
      "success": false,
      "message": "Failed to load department requests: $e",
      "data": [],
    };
  }
}


}
