import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../services/api_service.dart';
import 'dashboard_page.dart';
import 'signatories_page.dart';
import 'profile_page.dart';

class MyClearancePage extends StatefulWidget {
  const MyClearancePage({super.key});

  @override
  State<MyClearancePage> createState() => _MyClearancePageState();
}

class _MyClearancePageState extends State<MyClearancePage> {
  // UI state
  int selectedIndex = 1;
  String selectedYear = "2025–2026";        // just for dropdown display
  String selectedSemester = "First Semester";
  String facultyId = "faculty123";          // TODO: replace with login session

  Future<Map<String, dynamic>>? clearanceFuture;

  final List<String> departments = const [
    "Registrar",
    "Library",
    "Accounting",
    "HRMDO",
    "ITSO",
    "Research",
    "Extension Services",
    "Guidance",
    "Clinic",
    "Property Custodian",
    "Treasurer",
    "VPAA",
    "Dean"
  ];

  @override
  void initState() {
    super.initState();
    _reloadClearance(); // first load
  }

  void _reloadClearance() {
    setState(() {
      clearanceFuture = ApiService.getClearanceRequests(facultyId);
    });
  }

  // ==========================================================
  // MAIN LAYOUT
  // ==========================================================
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, constraints) {
      bool isMobile = constraints.maxWidth < 800;

      return Scaffold(
        drawer: isMobile ? _buildSidebar() : null,
        body: Row(
          children: [
            if (!isMobile) _buildSidebar(),
            Expanded(child: SafeArea(top: false, child: _buildContent())),
          ],
        ),
      );
    });
  }

  // ==========================================================
  // SIDEBAR
  // ==========================================================
  Widget _buildSidebar() {
    return Container(
      width: 260,
      color: const Color(0xFFF9F9F9),
      child: Column(children: [
        const SizedBox(height: 30),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Image.asset("assets/sdca_logo.png", width: 50),
          const SizedBox(width: 10),
          const Text("Faculty\nAcademic Clearance",
              style: TextStyle(fontWeight: FontWeight.bold)),
        ]),

        const SizedBox(height: 30),
        _menuButton(Icons.dashboard, "Dashboard", 0),
        _menuButton(Icons.article, "My Clearance", 1),
        _menuButton(Icons.account_tree, "Signatories", 2),
        _menuButton(Icons.person, "Profile", 3),

        const Spacer(),

        Padding(
          padding: const EdgeInsets.all(12),
          child: OutlinedButton.icon(
            onPressed: () => Navigator.pushNamedAndRemoveUntil(
                context, "/login", (route) => false),
            icon: const Icon(Icons.logout),
            label: const Text("Logout"),
            style: OutlinedButton.styleFrom(
              minimumSize: const Size(double.infinity, 45),
            ),
          ),
        )
      ]),
    );
  }

  Widget _menuButton(IconData icon, String label, int index) {
    bool active = selectedIndex == index;

    return InkWell(
      onTap: () {
        setState(() => selectedIndex = index);

        if (index == 0) {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => const DashboardPage()));
        }
        if (index == 2) {
          Navigator.push(context,
              MaterialPageRoute(builder: (_) => const SignatoriesPage()));
        }
        if (index == 3) {
          Navigator.push(
              context, MaterialPageRoute(builder: (_) => const ProfilePage()));
        }
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 20),
        color: active ? const Color(0xFFEEEDED) : Colors.transparent,
        child: Row(children: [
          Icon(icon, color: Colors.black87),
          const SizedBox(width: 12),
          Text(label, style: const TextStyle(fontSize: 16)),
        ]),
      ),
    );
  }

  // ==========================================================
  // MAIN CONTENT AREA
  // ==========================================================
  Widget _buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(30, 10, 30, 30),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text("Clearance Requests",
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const Text("Track and manage clearance requests",
            style: TextStyle(fontSize: 16, color: Colors.black54)),
        const SizedBox(height: 30),

        _buildCounters(),

        const SizedBox(height: 30),
        Row(children: [_yearDropdown(), const SizedBox(width: 20), _semesterDropdown()]),
        const SizedBox(height: 20),

        _buildClearanceReportList(),
      ]),
    );
  }

  // ==========================================================
  // COUNTERS
  // ==========================================================
  Widget _buildCounters() {
    return FutureBuilder<Map<String, dynamic>>(
      future: clearanceFuture,
      builder: (context, snapshot) {
        int total = 0, pending = 0, approved = 0, rejected = 0;

        if (snapshot.hasData && snapshot.data!["success"] == true) {
          final List list = snapshot.data!["data"];

          total = list.length;
          pending = list.where((r) => r["status"] == "Pending").length;
          approved = list.where((r) => r["status"] == "Approved").length;
          rejected = list.where((r) => r["status"] == "Rejected").length;
        }

        return Row(children: [
          _numberCard("Total Request", "$total"),
          const SizedBox(width: 20),
          _numberCard("Pending", "$pending", color: Colors.orange),
          const SizedBox(width: 20),
          _numberCard("Approved", "$approved", color: Colors.green),
          const SizedBox(width: 20),
          _numberCard("Rejected", "$rejected", color: Colors.red),
        ]);
      },
    );
  }

  // ==========================================================
  // REPORT LIST (ALWAYS 13 DEPARTMENTS)
  // ==========================================================
  Widget _buildClearanceReportList() {
    return FutureBuilder<Map<String, dynamic>>(
      future: clearanceFuture,
      builder: (context, snapshot) {
        Map<String, dynamic> latest = {};

        if (snapshot.hasData && snapshot.data!["success"] == true) {
          for (var r in snapshot.data!["data"]) {
            latest[r["department"]] = r;
          }
        }

        return Column(
          children: departments.map((dept) {
            final data = latest[dept];

            return _departmentCard(
              department: dept,
              status: data?["status"] ?? "No Status",
              submitted: data?["submitted_on"],
              approved: data?["approved_on"],
              semester: data?["semester"],
              id: data?["_id"],
            );
          }).toList(),
        );
      },
    );
  }

  // ==========================================================
  // HELPERS
  // ==========================================================
  String formatDate(dynamic date) {
    if (date == null || date.toString().trim().isEmpty) return "-";
    try {
      final parsed = DateTime.parse(date.toString());
      return DateFormat("MMMM dd, yyyy").format(parsed);
    } catch (_) {
      return date.toString();
    }
  }

  // ==========================================================
  // ONE DEPARTMENT CARD
  // ==========================================================
  Widget _departmentCard({
    required String department,
    required String status,
    String? submitted,
    String? approved,
    String? semester,
    String? id,
  }) {
    Color statusColor =
        status == "Approved" ? Colors.green :
        status == "Rejected" ? Colors.red :
        status == "Pending"  ? Colors.orange :
        Colors.blue; // No Status

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      padding: const EdgeInsets.all(20),
      decoration: _boxStyle(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [

          // HEADER
          Row(
            children: [
              const Icon(Icons.account_balance, color: Colors.blue),
              const SizedBox(width: 10),
              Text(department, style: const TextStyle(fontWeight: FontWeight.bold)),
              const Spacer(),
              Chip(
                label: Text(status),
                backgroundColor: statusColor.withOpacity(0.15),
                labelStyle: TextStyle(color: statusColor),
              ),
            ],
          ),

          const SizedBox(height: 12),

          if (submitted != null)
            Text("📅 Submitted: ${formatDate(submitted)}"),
          if (approved != null)
            Text("📅 Approved: ${formatDate(approved)}"),
          if (semester != null)
            Text("🏫 Semester: $semester"),

          const SizedBox(height: 20),

          // ===================================================================== ACTION BUTTONS

          // 1) SEND REQUEST (No Status)
          if (status == "No Status")
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              onPressed: () async {
                final res = await ApiService.sendDepartmentRequest(
                  facultyId: facultyId,
                  department: department,
                  year: selectedYear,
                  semester: selectedSemester,
                );
                if (res["success"] == true) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Request Sent!")));
                  _reloadClearance();   // ✅ refresh right after
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(res["message"] ?? "Failed to send")));
                }
              },
              child: const Text("Send Request", style: TextStyle(color: Colors.white)),
            ),

          // 2) PENDING → View Details + Submit Requirements
          if (status == "Pending" && id != null) ...[
            OutlinedButton(
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Viewing request details...")));
              },
              child: const Text("View Details"),
            ),
            const SizedBox(height: 10),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              onPressed: () {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text("Requirement submit coming next 🔥")));
              },
              child: const Text("Submit Requirements"),
            ),
          ],

          // 3) REJECTED → Resubmit
          if (status == "Rejected" && id != null)
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              onPressed: () async {
                final res = await ApiService.resubmitClearanceRequest(id);
                if (res["success"] == true) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Request Re-Submitted")));
                  _reloadClearance();   // ✅ refresh
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(res["message"] ?? "Failed to resubmit")));
                }
              },
              child: const Text("Resubmit", style: TextStyle(color: Colors.white)),
            ),

          // 4) APPROVED → Download
          if (status == "Approved")
            OutlinedButton(
              onPressed: () {},
              child: const Text("Download Clearance"),
            ),
        ],
      ),
    );
  }

  // ==========================================================
  // SMALL UI HELPERS
  // ==========================================================
  Widget _numberCard(String label, String number,
      {Color color = Colors.black}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: _boxStyle(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: const TextStyle(color: Colors.black54)),
            Text(number,
                style: TextStyle(
                    fontSize: 24, fontWeight: FontWeight.bold, color: color)),
          ],
        ),
      ),
    );
  }

  Widget _yearDropdown() {
    return _dropdown(selectedYear, const ["2023–2024", "2024–2025", "2025–2026"],
        (v) => setState(() => selectedYear = v));
  }

  Widget _semesterDropdown() {
    return _dropdown(selectedSemester,
        const ["First Semester", "Second Semester"],
        (v) => setState(() => selectedSemester = v));
  }

  Widget _dropdown(
      String value, List<String> list, void Function(String) pick) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: _boxStyle(),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: value,
          items: list
              .map((e) => DropdownMenuItem(value: e, child: Text(e)))
              .toList(),
          onChanged: (v) => pick(v!),
        ),
      ),
    );
  }

  BoxDecoration _boxStyle() => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [
          BoxShadow(
              color: Colors.black12, blurRadius: 8, offset: Offset(0, 2)),
        ],
      );
}
