import 'dart:async';
import 'package:flutter/material.dart';
import '../../../services/api_service.dart';
import '../dashboard_page.dart';
import '../profile_page.dart';

class RegistrarApprovalsPage extends StatefulWidget {
  const RegistrarApprovalsPage({super.key});

  @override
  State<RegistrarApprovalsPage> createState() => _RegistrarApprovalsPageState();
}

class _RegistrarApprovalsPageState extends State<RegistrarApprovalsPage> {
  int selectedIndex = 1;

  final String department = "Registrar";

  /// MUST MATCH DB (with EN DASH "–")
  String selectedYear = "2025–2026";
  String selectedSemester = "First Semester";

  Future<Map<String, dynamic>>? requestsFuture;

  @override
  void initState() {
    super.initState();
    loadRequests();
  }

  void loadRequests() {
    requestsFuture = ApiService.getDepartmentRequests(department);
    setState(() {});
  }

  Future<void> updateStatus(String id, String newStatus) async {
    final resp = await ApiService.updateClearanceStatus(id, newStatus);

    if (resp["success"] == true) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text("Status → $newStatus")));
      loadRequests();
    }
  }

  // ===================================================================== UI
  @override
  Widget build(BuildContext context) {
    final mobile = MediaQuery.of(context).size.width < 800;

    return Scaffold(
      drawer: mobile ? buildSidebar() : null,
      body: Row(children: [
        if (!mobile) buildSidebar(),
        Expanded(child: SafeArea(child: buildContent()))
      ]),
    );
  }

  // ===================================================================== SIDEBAR
  Widget buildSidebar() {
    return Container(
      width: 260,
      color: const Color(0xFFF9F9F9),
      child: Column(children: [
        const SizedBox(height: 30),
        Image.asset("assets/sdca_logo.png", width: 50),
        const SizedBox(height: 10),
        const Text("Admin\nAcademic Clearance",
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 30),

        menuButton(Icons.dashboard, "Dashboard", 0),
        menuButton(Icons.fact_check, "Approvals", 1),
        menuButton(Icons.person, "Profile", 2),

        const Spacer(),
        Padding(
          padding: const EdgeInsets.all(12),
          child: OutlinedButton.icon(
            onPressed: () => Navigator.pushNamedAndRemoveUntil(
                context, "/login", (route) => false),
            icon: const Icon(Icons.logout),
            label: const Text("Logout"),
          ),
        )
      ]),
    );
  }

  Widget menuButton(IconData icon, String text, int index) {
    final active = selectedIndex == index;

    return InkWell(
      onTap: () {
        setState(() => selectedIndex = index);
        if (index == 0) Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminDashboardPage()));
        if (index == 2) Navigator.push(context, MaterialPageRoute(builder: (_) => const AdminProfilePage()));
      },
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 20),
        color: active ? Colors.grey.shade200 : Colors.transparent,
        child: Row(children: [
          Icon(icon, color: Colors.black87),
          const SizedBox(width: 10),
          Text(text, style: TextStyle(fontSize: 16))
        ]),
      ),
    );
  }

  // ===================================================================== CONTENT
  Widget buildContent() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(30),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text("Approvals",
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const Text("Review Registrar clearance requests",
            style: TextStyle(color: Colors.black54)),

        const SizedBox(height: 30),
        _buildCounters(),

        const SizedBox(height: 30),
        Row(children:[yearDropdown(), const SizedBox(width:20), semesterDropdown()]),

        const SizedBox(height: 25),
        _buildRequestsList(),
      ]),
    );
  }

  // ================= COUNTERS ===================
  Widget _buildCounters() {
    return FutureBuilder<Map<String, dynamic>>(
      future: requestsFuture,
      builder: (context, snapshot) {
        final List all = (snapshot.hasData && snapshot.data?["data"] is List)
            ? snapshot.data!["data"]
            : [];

        final filtered = all.where((r) =>
          r["academic_year"] == selectedYear &&
          r["semester"] == selectedSemester
        ).toList();

        return Row(children: [
          statCard("Total Request", "${filtered.length}"),
          SizedBox(width: 20),
          statCard("Pending", "${filtered.where((r)=>r["status"]=="Pending").length}", color: Colors.orange),
          SizedBox(width: 20),
          statCard("Approved","${filtered.where((r)=>r["status"]=="Approved").length}", color: Colors.green),
          SizedBox(width: 20),
          statCard("Rejected","${filtered.where((r)=>r["status"]=="Rejected").length}", color: Colors.red),
        ]);
      },
    );
  }

  // ================= REQUEST LIST ===================
  Widget _buildRequestsList() {
    return FutureBuilder<Map<String, dynamic>>(
      future: requestsFuture,
      builder: (context, snapshot) {
        final List all = (snapshot.hasData && snapshot.data?["data"] is List)
            ? snapshot.data!["data"]
            : [];

        final filtered = all.where((r) =>
          r["academic_year"] == selectedYear &&
          r["semester"] == selectedSemester
        ).toList();

        if (filtered.isEmpty) {
          return Padding(
            padding: EdgeInsets.all(30),
            child: Text("No clearance requests found.",
                style: TextStyle(fontSize: 16, color: Colors.black54)),
          );
        }

        return Column(
          children: filtered.map((r)=>requestCard(Map<String,dynamic>.from(r))).toList()
        );
      }
    );
  }

  // ===================================================================== CARD UI — (NEW LOGIC INSTALLED)
  Widget requestCard(r) {
    return Container(
      padding: const EdgeInsets.all(20),
      margin: const EdgeInsets.only(bottom: 20),
      decoration: boxStyle(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[

        Row(children:[
          Icon(Icons.person,size:26),
          SizedBox(width:8),
          Text("Faculty: ${r["faculty_id"]}",
              style: TextStyle(fontWeight: FontWeight.bold,fontSize:16)),
          Spacer(),
          Chip(
            label: Text(r["status"]),
            backgroundColor: statusColor(r["status"]).withOpacity(.2),
            labelStyle: TextStyle(color: statusColor(r["status"])),
          )
        ]),

        SizedBox(height:6),
        Text("Academic Year: ${r["academic_year"]}"),
        Text("Semester: ${r["semester"]}"),
        Text("Submitted: ${r["submitted_on"]}"),

        SizedBox(height:14),

        Row(children:[

          // 🔥 NO STATUS → ONLY PEND
          if(r["status"] == "No Status")
            ElevatedButton(
              onPressed:()=>updateStatus(r["_id"],"Pending"),
              style:ElevatedButton.styleFrom(backgroundColor:Colors.orange),
              child:Text("Pend"),
            ),

          // 🔥 PENDING → Approve + Reject + View Details
          if(r["status"]=="Pending") ...[
            ElevatedButton(
              onPressed:()=>updateStatus(r["_id"],"Approved"),
              style:ElevatedButton.styleFrom(backgroundColor:Colors.green),
              child:Text("Approve")),
            SizedBox(width:10),
            ElevatedButton(
              onPressed:()=>updateStatus(r["_id"],"Rejected"),
              style:ElevatedButton.styleFrom(backgroundColor:Colors.red),
              child:Text("Reject")),
            SizedBox(width:10),
            OutlinedButton(
              onPressed:(){
                // Next feature → Requirements panel
              },
              child:Text("View Details"),
            ),
          ],

          // 🔥 APPROVED / REJECTED → VIEW ONLY
          if(r["status"]=="Approved" || r["status"]=="Rejected")
            OutlinedButton(
              onPressed:(){},
              child:Text("View Details"),
            ),
        ])
      ])
    );
  }

  // ===================================================================== HELPERS
  Widget statCard(String title,String num,{Color color = Colors.black}) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: boxStyle(),
        child: Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(title, style:TextStyle(color:Colors.black54)),
          SizedBox(height:6),
          Text(num,style:TextStyle(fontSize:22,fontWeight:FontWeight.bold,color:color))
        ])
      )
    );
  }

  Widget yearDropdown()=>Container(
    padding:EdgeInsets.symmetric(horizontal:16),
    decoration:boxStyle(),
    child:DropdownButtonHideUnderline(
      child:DropdownButton(
        value:selectedYear,
        items:["2025–2026"].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
        onChanged:(v)=>setState(()=>selectedYear=v!)
      )
    )
  );

  Widget semesterDropdown()=>Container(
    padding:EdgeInsets.symmetric(horizontal:16),
    decoration:boxStyle(),
    child:DropdownButtonHideUnderline(
      child:DropdownButton(
        value:selectedSemester,
        items:["First Semester","Second Semester"].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),
        onChanged:(v)=>setState(()=>selectedSemester=v!)
      )
    )
  );

  BoxDecoration boxStyle()=>BoxDecoration(
    color:Colors.white,
    borderRadius:BorderRadius.circular(12),
    boxShadow:[BoxShadow(color:Colors.black12,blurRadius:8,offset:Offset(0,2))]
  );

  Color statusColor(s){
    if(s=="Approved") return Colors.green;
    if(s=="Rejected") return Colors.red;
    if(s=="Pending")  return Colors.orange;
    return Colors.blue;
  }
}
