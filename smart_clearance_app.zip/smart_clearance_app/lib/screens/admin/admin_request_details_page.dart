import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../services/api_service.dart';

class AdminRequestDetailsPage extends StatefulWidget {
  final String requestId;

  const AdminRequestDetailsPage({super.key, required this.requestId});

  @override
  State<AdminRequestDetailsPage> createState() => _AdminRequestDetailsPageState();
}

class _AdminRequestDetailsPageState extends State<AdminRequestDetailsPage> {
  bool loading = true;
  Map<String, dynamic>? data;

  @override
  void initState() {
    super.initState();
    loadRequestDetails();
  }
      Future<void> loadRequestDetails() async {
        final res = await ApiService.getRequestById(widget.requestId);

        if (!mounted) return;
        setState(() {
          data = res["data"];
          loading = false;
        });
      }


  String fmt(dynamic d) {
    if (d == null) return "-";
    try {
      return DateFormat("MMM dd, yyyy").format(DateTime.parse(d.toString()));
    } catch (_) {
      return "-";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F2FF),
      body: SafeArea(
        child: loading
            ? const Center(child: CircularProgressIndicator())
            : SingleChildScrollView(
                padding: const EdgeInsets.all(30),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

                  // 🔙 BACK
                  TextButton.icon(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back, color: Colors.black),
                    label: const Text("Back", style: TextStyle(color: Colors.black)),
                  ),

                  const SizedBox(height: 10),

                  // 🔥 HEADER
                  Row(
                    children: [
                      const Icon(Icons.domain_verification, size: 28, color: Colors.blue),
                      const SizedBox(width: 10),
                      Text(data?["department"] ?? "Department",
                          style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                      const Spacer(),
                      Chip(
                        label: Text(data?["status"] ?? "Unknown"),
                        backgroundColor: Colors.orange.shade200,
                        labelStyle: const TextStyle(color: Colors.orange),
                      )
                    ],
                  ),

                  const SizedBox(height: 5),
                  Text("Request ID: ${data?["_id"] ?? widget.requestId}",
                  style: const TextStyle(color: Colors.black54)),

                  const SizedBox(height: 20),

                  // ===== TABS (Details + OCR Scanner) =====
                  Row(
                    children: [
                      // DETAILS TAB (active)
                      ElevatedButton(
                        onPressed: () {}, // this page is already Details
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.black,
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                        ),
                        child: const Text("Details", style: TextStyle(color: Colors.white)),
                      ),

                      const SizedBox(width: 10),

                      // OCR TAB — backend later
                      OutlinedButton(
                        onPressed: () {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text("OCR Scanner feature coming soon 👀")),
                          );
                        },
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.black87),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 12),
                        ),
                        child: const Text("OCR Scanner", style: TextStyle(color: Colors.black)),
                      ),
                    ],
                  ),

              const SizedBox(height: 25),

                  // ========== Request Info ==========
                  Container(
                    padding: const EdgeInsets.all(20),
                    decoration: box(),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Text("Request Information",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),

                      const SizedBox(height: 15),
                      Row(children: [
                        Expanded(child: field("Faculty ID", data?["faculty_id"])),
                        Expanded(child: field("Department", data?["department"])),
                      ]),
                      const SizedBox(height: 20),

                      Row(children: [
                        Expanded(child: field("Submitted", fmt(data?["submitted_on"]))),
                        Expanded(child: field("Approved", fmt(data?["approved_on"]))),
                      ]),
                    ]),
                  ),

                  const SizedBox(height: 25),

                  // ========== Required Documents ==========
                  documentsSection(),

                ]),
              ),
      ),
    );
  }

  // ===================== REQUIRED DOCUMENT SECTION =====================
  Widget documentsSection() {
    List docs = data?["required_documents"] ?? [];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: box(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

        // Header + Button
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text("Required Documents",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ElevatedButton(
              onPressed: showAddRequiredDocDialog,
              style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
              child: const Text("Insert for Faculty"),
            )
          ],
        ),

        const SizedBox(height: 8),
        const Text("Documents faculty must submit", style: TextStyle(color: Colors.black54)),

        const SizedBox(height: 15),

        // No docs yet
        if (docs.isEmpty)
          const Padding(
            padding: EdgeInsets.all(12),
            child: Text("No required documents added.",
                style: TextStyle(color: Colors.black54)),
          ),

        // If docs exist → show list
        if (docs.isNotEmpty)
          ...docs.map((d) => docRow(d)).toList(),
      ]),
    );
  }

  // Each document row
 Widget docRow(doc) {
  bool submitted = (doc["file"] != null && doc["file"] != "");

  return Container(
    margin: const EdgeInsets.only(bottom: 10),
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(
      color: Colors.grey.shade100,
      borderRadius: BorderRadius.circular(10),
    ),
    child: Row(
      children: [
        Expanded(
          child: Text(
            doc["name"],
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
          ),
        ),

        submitted
            ? OutlinedButton(
                onPressed: () {
                  // soon support file viewer
                },
                child: const Text("View"),
              )
            : const Text(
                "Pending",
                style: TextStyle(color: Colors.orange, fontWeight: FontWeight.bold),
              ),
      ],
    ),
  );
}


  // ===================== Add Requirement Dialog =====================
  void showAddRequiredDocDialog() {
    TextEditingController input = TextEditingController();

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text("Insert Required Document"),
        content: TextField(controller: input, decoration: const InputDecoration(hintText: " ")),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),

          ElevatedButton(
            onPressed: () async {
              if (input.text.trim().isEmpty) return;

              await ApiService.addRequiredDocument(widget.requestId, input.text.trim());
              Navigator.pop(context);

              loadRequestDetails(); // refresh
            },
            child: const Text("Add"),
          )
        ],
      ),
    );
  }

  // ===================== UI Components =====================
  Widget field(String title, value) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(color: Colors.black54)),
        const SizedBox(height: 4),
        Text(value ?? "-", style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
      ]);

  BoxDecoration box() => BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8)],
      );
}
