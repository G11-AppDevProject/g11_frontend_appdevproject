package com.example.smart_clearance_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
